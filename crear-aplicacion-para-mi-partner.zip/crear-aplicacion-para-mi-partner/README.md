# Crear aplicación para mi partner (starter)

Esto es un sitio **estático** (sin base de datos) pensado **mobile-first**.

## Archivos
- `index.html`
- `styles.css`

## Probar local
Abre `index.html` con tu navegador.

## Publicar (dos caminos)
### 1) Netlify (rápido)
- En Netlify, usa *Deploy manually / Drag & Drop* y sube el ZIP o la carpeta.

### 2) GitHub Pages (pro)
- Sube estos archivos a un repo.
- En *Settings → Pages*, habilita Pages.
